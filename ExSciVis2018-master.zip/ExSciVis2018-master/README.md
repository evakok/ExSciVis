ExSciVis
===========

Framework for exercise 02.

How To Install:
* Download Framework
* Install CMake
* Use cmake to generate sln file (Source Dir: /root Target Dir: /root/cmake-out)
* Visual Studio only: Go to the Project Properties for "MyVolumeRaycaster" and change the working dir to *..\build\Debug* (PROJECT -> PROPERTIES -> Configuration Properties -> Debugging -> Working Directory)
* Compile and run
 

GUI created with ImGui
https://github.com/ocornut/imgui
